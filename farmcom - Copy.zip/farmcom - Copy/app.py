from werkzeug.security import generate_password_hash, check_password_hash
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import bcrypt
import os
from datetime import datetime, timedelta
from werkzeug.utils import secure_filename
from PIL import Image
import uuid

app = Flask(__name__)
app.config.from_object('config.Config')

# MySQL configuration
import mysql.connector
from mysql.connector import Error

# Database connection function using mysql.connector (this works!)
def get_db_connection():
    try:
        connection = mysql.connector.connect(
            host=app.config['MYSQL_HOST'],
            user=app.config['MYSQL_USER'],
            password=app.config['MYSQL_PASSWORD'],
            database=app.config['MYSQL_DB'],
            port=app.config.get('MYSQL_PORT', 3306)
        )
        return connection
    except Error as e:
        print(f"Database connection error: {e}")
        return None

# Allowed file extensions for image uploads
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Helper function to hash passwords
def hash_password(password):
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

def check_password(password, hashed):
    return bcrypt.checkpw(password.encode('utf-8'), hashed)

# Home page
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        try:
            print("=== Registration Debug ===")
            print(f"MySQL object: {mysql}")
            print(f"Has connection attr: {hasattr(mysql, 'connection')}")
            
            if hasattr(mysql, 'connection'):
                print(f"Connection value: {mysql.connection}")
            
            # Try to get connection
            conn = get_db_connection()
            print(f"Got connection: {conn}")
            
            if conn is None:
                flash('Database connection is None. Check if MySQL server is running.')
                return redirect(url_for('register'))
            
            # Get form data - matching your HTML form fields
            username = request.form['username']
            email = request.form['email']
            password = request.form['password']
            confirm_password = request.form['confirm_password']
            first_name = request.form.get('first_name', '')
            last_name = request.form.get('last_name', '')
            phone = request.form.get('phone', '')
            location = request.form.get('location', '')
            user_type = request.form.get('user_type', '')
            
            # Validate password confirmation
            if password != confirm_password:
                flash('Passwords do not match!', 'error')
                return redirect(url_for('register'))
            
            # Combine first and last name
            full_name = f"{first_name} {last_name}".strip()
            
            password_hash = generate_password_hash(password)
            
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO users (username, email, password_hash, full_name, phone, location, user_type) 
                VALUES (%s, %s, %s, %s, %s, %s, %s);
            """, (username, email, password_hash, full_name, phone, location, user_type))
            conn.commit()
            cursor.close()
            conn.close()
            
            flash('Registration successful!')
            return redirect(url_for('login'))
            
        except Exception as e:
            print(f"Registration error: {e}")
            flash(f'Registration failed: {str(e)}')
            return redirect(url_for('register'))
    
    return render_template('register.html')

# User Login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT id, username, password_hash, full_name FROM users WHERE username = %s", (username,))
            user = cursor.fetchone()
            cursor.close()
            conn.close()  
            
            if user and check_password_hash(user[2], password):
                session['user_id'] = user[0]
                session['username'] = user[1]
                session['full_name'] = user[3]
                flash('Login successful!', 'success')
                return redirect(url_for('dashboard'))
            else:
                flash('Invalid username or password!', 'error')
        except Exception as e:
            flash(f'Login failed: {str(e)}', 'error')
    
    return render_template('login.html')

# User Logout
@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))

# Dashboard
@app.route('/dashboard')
def dashboard():
    # Check if user is logged in
    if 'user_id' not in session:
        flash('Please log in to access the dashboard.', 'error')
        return redirect(url_for('login'))
    
    # Get user data from session
    user_data = {
        'id': session['user_id'],
        'username': session['username'],
        'full_name': session['full_name']
    }
    
    # Get user's equipment and items
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get user's equipment rentals
        cursor.execute("""
            SELECT id, equipment_name, description, category, rental_price_per_day, 
                   availability_status, created_at
            FROM equipment_rentals 
            WHERE owner_id = %s
            ORDER BY created_at DESC
            LIMIT 5
        """, (session['user_id'],))
        user_equipment = cursor.fetchall()
        
        # Get user's marketplace items
        cursor.execute("""
            SELECT id, item_name, description, category, price, quantity_available, 
                   created_at
            FROM marketplace_items 
            WHERE seller_id = %s
            ORDER BY created_at DESC
            LIMIT 5
        """, (session['user_id'],))
        user_items = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
    except Exception as e:
        print(f"Dashboard error: {e}")
        user_equipment = []
        user_items = []
    
    return render_template('dashboard.html', 
                         current_user=user_data,
                         equipment=user_equipment, 
                         items=user_items)

@app.route('/rent_equipment')
def rent_equipment():
    # Check if user is logged in
    if 'user_id' not in session:
        flash('Please log in to access this page.', 'error')
        return redirect(url_for('login'))
    
    # Your rent equipment logic here
    return render_template('rent_equipment.html')

@app.route('/rent_listings')
def rent_listings():
    # Check if user is logged in
    if 'user_id' not in session:
        flash('Please log in to access this page.', 'error')
        return redirect(url_for('login'))
    
    # Get rental listings from database
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT e.id, e.equipment_name, e.description, e.category, e.rental_price_per_day,
                   e.location, e.image_url, u.full_name, u.phone
            FROM equipment_rentals e
            JOIN users u ON e.owner_id = u.id
            WHERE e.availability_status = 'available'
            ORDER BY e.created_at DESC
        """)
        listings = cursor.fetchall()
        cursor.close()
        conn.close()
        
        return render_template('rent_listings.html', listings=listings)
    except Exception as e:
        flash(f'Error loading listings: {str(e)}', 'error')
        return redirect(url_for('dashboard'))

@app.route('/buy_items')
def buy_items():
    """Browse items available for purchase"""
    if 'user_id' not in session:
        flash('Please log in to access this page.', 'error')
        return redirect(url_for('login'))
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT m.id, m.item_name, m.description, m.category, m.price, m.quantity_available,
                   m.unit, m.location, m.image_url, u.full_name, u.phone
            FROM marketplace_items m
            JOIN users u ON m.seller_id = u.id
            WHERE m.quantity_available > 0
            ORDER BY m.created_at DESC
        """)
        items = cursor.fetchall()
        cursor.close()
        conn.close()
        
        return render_template('buy_items.html', items=items)
    except Exception as e:
        flash(f'Error loading items: {str(e)}', 'error')
        return redirect(url_for('dashboard'))

# NEW: Sell Item Route
@app.route('/sell_item', methods=['GET', 'POST'])
def sell_item():
    """Route for selling items in the marketplace"""
    if 'user_id' not in session:
        flash('Please log in to sell items.', 'error')
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        try:
            # Get form data
            item_name = request.form['item_name']
            description = request.form['description']
            category = request.form['category']
            price = float(request.form['price'])
            quantity = int(request.form['quantity'])
            unit = request.form['unit']
            location = request.form['location']
            
            # Handle image upload
            image_url = None
            if 'image' in request.files:
                file = request.files['image']
                if file and allowed_file(file.filename):
                    filename = str(uuid.uuid4()) + '.' + file.filename.rsplit('.', 1)[1].lower()
                    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                    file.save(file_path)
                    image_url = filename
            
            # Save to database
            conn = get_db_connection()
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO marketplace_items 
                (seller_id, item_name, description, category, price, quantity_available, unit, location, image_url)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (session['user_id'], item_name, description, category, price, quantity, unit, location, image_url))
            
            conn.commit()
            cursor.close()
            conn.close()
            
            flash('Item listed for sale successfully!', 'success')
            return redirect(url_for('dashboard'))
            
        except Exception as e:
            flash(f'Error listing item: {str(e)}', 'error')
            return redirect(url_for('sell_item'))
    
    # GET request - show the sell item form
    return render_template('sell_item.html')

# NEW: My Listings Route
@app.route('/my_listings')
def my_listings():
    """View current user's marketplace listings"""
    if 'user_id' not in session:
        flash('Please log in to view your listings.', 'error')
        return redirect(url_for('login'))
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, item_name, description, category, price, quantity_available, 
                   unit, location, image_url, created_at
            FROM marketplace_items 
            WHERE seller_id = %s
            ORDER BY created_at DESC
        """, (session['user_id'],))
        
        listings = cursor.fetchall()
        cursor.close()
        conn.close()
        
        return render_template('my_listings.html', listings=listings)
        
    except Exception as e:
        flash(f'Error loading your listings: {str(e)}', 'error')
        return redirect(url_for('dashboard'))

# NEW: Edit Listing Route
@app.route('/edit_listing/<int:listing_id>', methods=['GET', 'POST'])
def edit_listing(listing_id):
    """Edit a marketplace listing"""
    if 'user_id' not in session:
        flash('Please log in to edit listings.', 'error')
        return redirect(url_for('login'))
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Check if the listing belongs to the current user
    cursor.execute("""
        SELECT * FROM marketplace_items 
        WHERE id = %s AND seller_id = %s
    """, (listing_id, session['user_id']))
    
    listing = cursor.fetchone()
    
    if not listing:
        flash('Listing not found or you do not have permission to edit it.', 'error')
        cursor.close()
        conn.close()
        return redirect(url_for('my_listings'))
    
    if request.method == 'POST':
        try:
            # Get form data
            item_name = request.form['item_name']
            description = request.form['description']
            category = request.form['category']
            price = float(request.form['price'])
            quantity = int(request.form['quantity'])
            unit = request.form['unit']
            location = request.form['location']
            
            # Handle image upload (optional - keep existing if no new image)
            image_url = listing[9]  # Keep existing image by default
            if 'image' in request.files:
                file = request.files['image']
                if file and allowed_file(file.filename):
                    filename = str(uuid.uuid4()) + '.' + file.filename.rsplit('.', 1)[1].lower()
                    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                    file.save(file_path)
                    image_url = filename
            
            # Update database
            cursor.execute("""
                UPDATE marketplace_items 
                SET item_name = %s, description = %s, category = %s, price = %s, 
                    quantity_available = %s, unit = %s, location = %s, image_url = %s
                WHERE id = %s AND seller_id = %s
            """, (item_name, description, category, price, quantity, unit, location, 
                  image_url, listing_id, session['user_id']))
            
            conn.commit()
            cursor.close()
            conn.close()
            
            flash('Listing updated successfully!', 'success')
            return redirect(url_for('my_listings'))
            
        except Exception as e:
            flash(f'Error updating listing: {str(e)}', 'error')
            cursor.close()
            conn.close()
            return redirect(url_for('edit_listing', listing_id=listing_id))
    
    cursor.close()
    conn.close()
    
    return render_template('edit_listing.html', listing=listing)

# NEW: Delete Listing Route
@app.route('/delete_listing/<int:listing_id>', methods=['POST'])
def delete_listing(listing_id):
    """Delete a marketplace listing"""
    if 'user_id' not in session:
        flash('Please log in to delete listings.', 'error')
        return redirect(url_for('login'))
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if the listing belongs to the current user
        cursor.execute("""
            DELETE FROM marketplace_items 
            WHERE id = %s AND seller_id = %s
        """, (listing_id, session['user_id']))
        
        if cursor.rowcount > 0:
            conn.commit()
            flash('Listing deleted successfully!', 'success')
        else:
            flash('Listing not found or you do not have permission to delete it.', 'error')
        
        cursor.close()
        conn.close()
        
    except Exception as e:
        flash(f'Error deleting listing: {str(e)}', 'error')
    
    return redirect(url_for('my_listings'))

# Equipment Rental Routes
@app.route('/rent/add', methods=['GET', 'POST'])
def add_equipment():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        equipment_name = request.form['equipment_name']
        description = request.form['description']
        category = request.form['category']
        rental_price_per_day = float(request.form['rental_price_per_day'])
        rental_price_per_week = float(request.form.get('rental_price_per_week', 0))
        rental_price_per_month = float(request.form.get('rental_price_per_month', 0))
        location = request.form['location']
        
        # Handle image upload
        image_url = None
        if 'image' in request.files:
            file = request.files['image']
            if file and allowed_file(file.filename):
                filename = str(uuid.uuid4()) + '.' + file.filename.rsplit('.', 1)[1].lower()
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(file_path)
                image_url = filename
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO equipment_rentals 
            (owner_id, equipment_name, description, category, rental_price_per_day, 
             rental_price_per_week, rental_price_per_month, location, image_url)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (session['user_id'], equipment_name, description, category, 
              rental_price_per_day, rental_price_per_week, rental_price_per_month, 
              location, image_url))
        conn.commit()
        
        cursor.close()
        conn.close()
        
        flash('Equipment added successfully!', 'success')
        return redirect(url_for('dashboard'))
    
    return render_template('rent_equipment.html')

# View all equipment for rent
@app.route('/rent/browse')
def browse_equipment():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT e.id, e.equipment_name, e.description, e.category, e.rental_price_per_day,
               e.location, e.image_url, u.full_name, u.phone
        FROM equipment_rentals e
        JOIN users u ON e.owner_id = u.id
        WHERE e.availability_status = 'available'
        ORDER BY e.created_at DESC
    """)
    equipment = cursor.fetchall()
    
    cursor.close()
    conn.close()
    
    return render_template('rent_listings.html', equipment=equipment)

# Marketplace Routes
@app.route('/marketplace/add', methods=['GET', 'POST'])
def add_item():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        item_name = request.form['item_name']
        description = request.form['description']
        category = request.form['category']
        price = float(request.form['price'])
        quantity = int(request.form['quantity'])
        unit = request.form['unit']
        location = request.form['location']
        
        # Handle image upload
        image_url = None
        if 'image' in request.files:
            file = request.files['image']
            if file and allowed_file(file.filename):
                filename = str(uuid.uuid4()) + '.' + file.filename.rsplit('.', 1)[1].lower()
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(file_path)
                image_url = filename
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO marketplace_items 
            (seller_id, item_name, description, category, price, quantity_available, unit, location, image_url)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (session['user_id'], item_name, description, category, price, quantity, unit, location, image_url))
        conn.commit()
        
        cursor.close()
        conn.close()
        
        flash('Item added successfully!', 'success')
        return redirect(url_for('dashboard'))
    
    return render_template('buy_items.html')

# View marketplace
@app.route('/marketplace')
def marketplace():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT m.id, m.item_name, m.description, m.category, m.price, m.quantity_available,
               m.unit, m.location, m.image_url, u.full_name, u.phone
        FROM marketplace_items m
        JOIN users u ON m.seller_id = u.id
        WHERE m.quantity_available > 0
        ORDER BY m.created_at DESC
    """)
    items = cursor.fetchall()
    
    cursor.close()
    conn.close()
    
    return render_template('marketplace.html', items=items)

# Rent equipment
@app.route('/rent/request/<int:equipment_id>', methods=['POST'])
def request_rental(equipment_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    start_date = request.form['start_date']
    end_date = request.form['end_date']
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Get equipment details
    cursor.execute("""
        SELECT owner_id, rental_price_per_day FROM equipment_rentals WHERE id = %s
    """, (equipment_id,))
    equipment = cursor.fetchone()
    
    if equipment:
        owner_id = equipment[0]
        daily_rate = equipment[1]
        
        # Calculate total amount
        start = datetime.strptime(start_date, '%Y-%m-%d')
        end = datetime.strptime(end_date, '%Y-%m-%d')
        days = (end - start).days + 1
        total_amount = days * daily_rate
        
        cursor.execute("""
            INSERT INTO rental_transactions 
            (equipment_id, renter_id, owner_id, rental_start_date, rental_end_date, total_amount)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (equipment_id, session['user_id'], owner_id, start_date, end_date, total_amount))
        conn.commit()
        
        flash('Rental request submitted successfully!', 'success')
    
    cursor.close()
    conn.close()
    
    return redirect(url_for('browse_equipment'))

# Purchase item
@app.route('/buy/<int:item_id>', methods=['POST'])
def purchase_item(item_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    quantity = int(request.form['quantity'])
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Get item details
    cursor.execute("""
        SELECT seller_id, price, quantity_available FROM marketplace_items WHERE id = %s
    """, (item_id,))
    item = cursor.fetchone()
    
    if item and item[2] >= quantity:
        seller_id = item[0]
        price = item[1]
        total_amount = quantity * price
        
        # Create purchase transaction
        cursor.execute("""
            INSERT INTO purchase_transactions 
            (item_id, buyer_id, seller_id, quantity, total_amount)
            VALUES (%s, %s, %s, %s, %s)
        """, (item_id, session['user_id'], seller_id, quantity, total_amount))
        
        # Update item quantity
        cursor.execute("""
            UPDATE marketplace_items SET quantity_available = quantity_available - %s
            WHERE id = %s
        """, (quantity, item_id))
        
        conn.commit()
        flash('Purchase successful!', 'success')
    else:
        flash('Insufficient quantity available!', 'error')
    
    cursor.close()
    conn.close()
    
    return redirect(url_for('marketplace'))

if __name__ == '__main__':
    # Create upload directory if it doesn't exist
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    app.run(debug=True)